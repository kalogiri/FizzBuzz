﻿using LibertyUtils;
using System;
using System.IO;
using WinSCP;

namespace FizzBuzz.Tools
{
    class ftpFileTransferTest : BaseDownloadScript
    {
        string ZipFolder;

        LibertyConfigExternalCredentials.Credential ftpCredentials;

        public ftpFileTransferTest()
        {
            DebugLogDir = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Test\DebugLog\";
            WorkingDir = @"C:\PPProject\c# Projects\Test\ppwatch\Ealing\Upload\WorkingFolder\";
            LiveDataDir = @"C:\PPProject\c# Projects\Test\ppwatch\Ealing\Upload\AwaitingUpload\";

            CredentialsPath = HostPath.ppwatch_1 + @"LibertyConfig\ExternalCredentials.xml";
            ftpCredentials = Credentials.Get("Capita - Production Server");

            ZipFolder = @"C:\PPProject\c# Projects\Test\FizzBuzzTests\FTPUtilsUpload\";

            MutexUtils.OpenMutexUnique("~TEST~");
            DirUtils.RecreateLogged(WorkingDir);

            Log.Write("Program Starts Here");
            //MoveToServerFTPSingleFile(@"/Processed Permits/");
            checkConnection();
        }

        private static void SessionFileTransferProgress(object sender, FileTransferProgressEventArgs e)
        {
            // New Line for every new File
            if ((_lastFileName != null) && (_lastFileName != e.FileName))
            {
                Console.WriteLine();
            }

            Console.Write("\r{0} ({1:P0})", e.FileName, e.FileProgress);

            // Remember a name of the last file reported
            _lastFileName = e.FileName;
        }

        private string[] GatherTheFiles()
        {
            string[] zipFilesToArchive = Directory.GetFiles(ZipFolder);
            return zipFilesToArchive;
        }
        private static string _lastFileName;
        private int numberUploaded;

        private void SendEmail()
        {
            int filesInNumeber = GatherTheFiles().Length;
            int filesUploaded = numberUploaded;

            Log.Write("Number of files came in: " + filesInNumeber + Environment.NewLine + "Number of files uploaded: " + filesUploaded);
        }
        private void checkConnection()
        {
            //Move these files to the ftp
            SessionOptions sessionOptions = establishConnection();
            Session session = new Session();
            try
            {
                using (session)
                {
                    session.Open(sessionOptions);
                    if (session.Opened)
                    {
                        Log.Write("Session Opened");
                    }
                    else
                    {
                        Log.Write("No Connection");
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Write("Exception: " + ex);
            }
        }
        private void MoveToServerFTPSingleFile(string serverFolder)
        {
            SessionOptions sessionOptions = establishConnection();
            Session session = new Session();
            try
            {
                string count;
                using (session)
                {
                    session.Open(sessionOptions);
                    if(session.Opened)
                    {
                        //if(session.FileExists(serverFolder + Path.GetFileName(@"C:\RG Scripts\FizzBuzz\Files\TEST.txt")))
                        //{
                        //    count = RandomUtils.IntegerString(5);    
                        //    Log.Write("File already exists");
                        //    session.PutFiles(@"C:\RG Scripts\FizzBuzz\Files\TEST.txt", serverFolder + Path.GetFileNameWithoutExtension(@"C:\RG Scripts\FizzBuzz\Files\TEST.txt") + "_" + count +".txt");
                        //}
                        Log.Write("Archive files...");
                        session.PutFiles(@"C:\RG Scripts\FizzBuzz\Files\TEST.txt", serverFolder);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Write("Exception: " + ex);
            }
        }

        private void MoveToServerFTP(string archiveFolder)
        {
            //Move these files to the ftp
            SessionOptions sessionOptions = establishConnection();
            Session session = new Session();
            try
            {
                using (session)
                {
                    session.FileTransferProgress += SessionFileTransferProgress;
                    session.Open(sessionOptions);
                    if (session.Opened)
                    {
                        Log.Write("Archiving Files...");
                        foreach (var wf in GatherTheFiles())
                        {
                            session.PutFiles(wf, archiveFolder);
                        }
                    }
                }
                Log.Write("Finished Archiving!");
            }
            catch (Exception ex)
            {
                Log.Write("Exception: " + ex);
            }
        }

        private void MoveToServerLibertyUtils()
        {
            string FileToSend = @"C:\PPProject\c# Projects\Test\FizzBuzzTests\FTPUtilsUpload\Test File.txt";
            string RemoteLoc = @"/TEST/";
            string archiveCommand = string.Concat(" put ", FileToSend, " ", RemoteLoc, Path.GetFileName(FileToSend));

            FTPUtils.Execute
            (
                credential: ftpCredentials,
                command: archiveCommand,
                disableWhenDebugging: false,
                useShellExecute: false
            );
        }

        private SessionOptions establishConnection()
        {
            int port = int.Parse(ftpCredentials.Server.Substring(ftpCredentials.Server.LastIndexOf(':') + 1));
            string server = ftpCredentials.Server;
            int serverIndex = ftpCredentials.Server.IndexOf(':');
            if (serverIndex > 0) { server = server.Substring(0, serverIndex); }

            SessionOptions sessionOptions = new SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = server,
                PortNumber = port,
                UserName = ftpCredentials.Username,
                Password = ftpCredentials.Password,
                GiveUpSecurityAndAcceptAnySshHostKey = true // This needs changing to have it go through a security protocol
            };
            return sessionOptions;
        }
    }
}

﻿using LibertyUtils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.Tools
{
    class LibertyUtilsLoadingBar : BaseDownloadScript
    {

        string From, To = string.Empty;

        public LibertyUtilsLoadingBar()
        {
            DebugLogDir = @"C:\PPProject\c# Projects\Test\FizzBuzzTests\LibertyUtilsLoadingBar\DebugLog\";
            From = @"C:\PPProject\c# Projects\Test\FizzBuzzTests\LibertyUtilsLoadingBar\From\";
            To = @"C:\PPProject\c# Projects\Test\FizzBuzzTests\LibertyUtilsLoadingBar\To\";
            try
            {
                string[] files = Directory.GetFiles(From);
                CopyFiles(files, To, ShowPercentageProgress, true);
            }
            catch (Exception ex)
            {
                Log.Write(ex);
            }
        }

        private void CopyFiles(string[] sourceFiles, string destPath, Action<string, long, long> reportProgress, bool create = false, int blockSizeToRead = 4096)
        {
            if (create == false)
            {
                if (!Directory.Exists(destPath))
                {
                    Log.Write(new DirectoryNotFoundException(destPath));
                }
            }
            else
            {
                Directory.CreateDirectory(destPath);
            }

            foreach (var sourceFile in sourceFiles)
            {
                if (!File.Exists(sourceFile))
                {
                    Log.Write(sourceFile + " not found. Skipping it.");
                }

                FileInfo sourceFileInfo = new FileInfo(sourceFile);
                string message = string.Format("Copying {0} ", sourceFileInfo.Name);
                string destFilePath = Path.Combine(destPath, sourceFileInfo.Name);
                byte[] buffer = new byte[blockSizeToRead];
                using (var destfs = File.OpenWrite(destFilePath))
                {
                    using (var sourcefs = File.OpenRead(sourceFile))
                    {
                        int bytesRead, totalBytesRead = 0;
                        while ((bytesRead = sourcefs.Read(buffer, 0, buffer.Length - 1)) > 0)
                        {
                            destfs.Write(buffer, 0, bytesRead);
                            totalBytesRead += bytesRead;
                            reportProgress?.Invoke(message, totalBytesRead, sourceFileInfo.Length);
                        }
                    }
                }
            }
        }

        private void ShowPercentageProgress(string message, long processed, long total)
        {
            long percent = (100 * (processed + 1)) / total;
            Log.Write("\r" + message + percent + " complete");
            if (processed >= total - 1)
            {
                Log.Write(Environment.NewLine);
            }
        }
    }
}

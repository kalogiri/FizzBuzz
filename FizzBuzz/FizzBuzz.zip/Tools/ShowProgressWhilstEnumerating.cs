﻿using System;
using CSharpTest.Net.IO;
using System.Threading;

namespace FizzBuzz.Tools
{
    class ShowProgressWhilstEnumerating
    {
        public ShowProgressWhilstEnumerating()
        {
            string Path = @"\\mass-storage\MassStorage\ParkingArchive\Haringey Council\";
            Compute(Path);
        }

        private void Compute(string PathToEnumerate)
        {
            long TOTAL = 0;
            FindFile FCOUNTER = new FindFile(
                rootDirectory: PathToEnumerate, 
                filePattern: "*", 
                recursive: true, 
                includeFolders: true, 
                includeFiles: true
            );

            FCOUNTER.RaiseOnAccessDenied = false;
            FCOUNTER.FileFound +=
            (o, e) => 
            {
                if (!e.IsDirectory)
                {
                    Interlocked.Increment(ref TOTAL);
                }
            };

            // Start a high-priority thread to perform the accumulation
            Thread t = new Thread(FCOUNTER.Find)
            {
                IsBackground = true,
                Priority = ThreadPriority.AboveNormal,
                Name = "file enum"
            };
            t.Start();

            // Allow the accumulator thread to get a head-start on us
            do { Thread.Sleep(100); }
            while (TOTAL < 100 && t.IsAlive);

            // Now we cna process the files normally and update a percentage
            long count = 0, percentage = 0;
            FindFile task = new FindFile
            (
                rootDirectory: PathToEnumerate,
                filePattern: "*",
                recursive: true,
                includeFolders: true,
                includeFiles: true
            );
            task.RaiseOnAccessDenied = false;
            task.FileFound +=
                (o, e) =>
                {
                    if (!e.IsDirectory)
                    {
                        // The File that gets processed here.
                        // DoSomeProcess()
                        long progress = ++count * 100 / Interlocked.Read(ref TOTAL);
                        if(progress > percentage && progress <= 100)
                        {
                            percentage = progress;
                            Console.WriteLine("{0}% complete.", percentage);
                        }
                    }
                };
            task.Find();
        }
    }
}

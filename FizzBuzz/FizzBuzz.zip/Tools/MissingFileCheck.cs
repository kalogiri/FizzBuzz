﻿using LibertyUtils;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FizzBuzz.Tools
{
    class MissingFileCheck : BaseDownloadScript
    {
        class FileClass
        {
            public string FileName { get; set; }
            public string filePath { get; set; }
            public bool pdf { get; set; }
            public bool txt { get; set; }
        }

        public MissingFileCheck()
        {
            DebugLogDir = @"C:\PPProject\c# Projects\Test\ppwatch\FindFolders\DebugFolder\";
            foreach (var dir in Directory.EnumerateDirectories(@"C:\PPProject\c# Projects\Test\FindFolders\", "*", SearchOption.AllDirectories))
            {
                // Check all dir except for "xx_NEW_xx"
                if (!dir.Contains("xx_NEW_xx"))
                {
                    thingy(dir);
                }
            }
        }

        private void thingy(string dir)
        {
            var list = new List<FileClass>();

            var dirConfig = new DirectoryInfo(dir);
            var allFiles = dirConfig.GetFiles("*");

            foreach (var fileInfo in allFiles)
            {
                var fileName = fileInfo.Name.Substring(0, fileInfo.Name.Length - fileInfo.Extension.Length);
                var fileClass = list.Where(fc => fc.FileName == fileName).FirstOrDefault();
                if (fileClass == null)
                {
                    fileClass = new FileClass
                    {
                        FileName = fileName,
                        filePath = Path.Combine(fileInfo.DirectoryName, fileName),
                        pdf = (fileInfo.Extension.ToLower() == ".pdf"),
                        txt = (fileInfo.Extension.ToLower() == ".txt")
                    };

                    list.Add(fileClass);
                }
                else
                {
                    switch (fileInfo.Extension.ToLower())
                    {
                        case ".pdf": fileClass.pdf = true; break;
                        case ".txt": fileClass.txt = true; break;
                    }
                }
            }

            foreach (var file in list)
            {
                if (file.txt == false)
                {
                    Log.Write("Missing: " + file.filePath + ".txt");
                }
                if (file.pdf == false)
                {
                    Log.Write("Missing: " + file.filePath + ".pdf");
                }
            }
        }
    }
}

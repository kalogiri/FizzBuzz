﻿using System.Xml.Linq;
using LibertyUtils;
using System;
using System.Xml;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace FizzBuzz.Tools
{
    public class CreatingACustomXML : BaseDownloadScript
    {
        public CreatingACustomXML()
        {
            DebugLogDir = @"C:\PPProject\c# Projects\Test\CreateCustomXML\";
            AddToXML(@"C:\PPProject\c# Projects\Missing File Checker\CheckFileConfig.xml", "Test Client 2", "Test Root 2", "Test Server Location 2", "xx_TEST_xx 2", ".pdf, .txt 2");
        }

        private void AddToXML(string XMLFilePath, string ClientName, string RootFolderName, string ServerLocation, string FoldersToSkip, string LookUpPatterns)
        {
            try
            {
                XDocument xDoc = XDocument.Load(XMLFilePath);
                XElement root = xDoc.Element("Clients");
                IEnumerable<XElement> rows = root.Descendants("Client");
                XElement firstRow = rows.First();
                firstRow.AddBeforeSelf(
                    new XElement("Client",
                        new XElement("ClientName", ClientName),
                        new XElement("ClientDetails", 
                            new XElement("RootFolder", RootFolderName),
                            new XElement("ServerLocation", ServerLocation),
                            new XElement("FullPath", ServerLocation + @"\" + ClientName + @"\"),
                            new XElement("FolderToSkip", FoldersToSkip),
                            new XElement("Patterns", LookUpPatterns)
                        )
                    )
                );
                xDoc.Save(XMLFilePath);
            }
            catch (Exception ex)
            {
                Log.Write(ex);
            }
        }
    }
}

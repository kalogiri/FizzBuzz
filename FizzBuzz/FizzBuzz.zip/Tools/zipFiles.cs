﻿using LibertyUtils;

namespace FizzBuzz.Tools
{
    class zipFiles : BaseDownloadScript
    {
        public zipFiles()
        {
            DebugLogDir = @"C:\RG Scripts\FizzBuzz\Debug\";
            zip();
        }

        private void zip()
        {
            Log.Default.Write("Starting Process");
            string[] zipLoc = { @"C:\RG Scripts\FizzBuzz\Zip1\", @"C:\RG Scripts\FizzBuzz\Zip2\" };
            foreach (var file in zipLoc)
            {
                ZipUtils.CompressLogged(@"C:\RG Scripts\FizzBuzz\Files\", file);
            }
        }
    }
}

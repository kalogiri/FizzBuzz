﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.Tools
{
    class CheckForFileExtension
    {
        public CheckForFileExtension()
        {
            string[] FilesToCheck = Directory.GetFiles(@"C:\PPProject\c# Projects\Test\ppwatch\Kingston\Test Files\", "*");

            foreach(var file in FilesToCheck)
            {
                if(!Path.HasExtension(file))
                {
                    Console.WriteLine(file);
                }
            }
        }
    }
}

﻿using LibertyUtils;
using System;
using System.IO;

namespace FizzBuzz.Scripts
{
    class LambethDataIntegrityCheck
    {
        public LambethDataIntegrityCheck()
        {
            Check();
        }

        private void Check()
        {
            string FolderToCheck = @"C:\RG Scripts\FizzBuzz\TestFolder\Lambeth\Data Files\";
            string QuarantinedFolder = @"C:\RG Scripts\FizzBuzz\TestFolder\Lambeth\Quarantine Folder\" + DateTime.Now.ToString("yyyyMMdd") + @"\";

            foreach (var file in new DirectoryInfo(FolderToCheck).GetFiles())
            {
                using (var CsvDoc = new CSVDocument(file.FullName) { Delimiter = "\t" })
                {
                    CsvDoc.LoadFile();
                    int RecordCount = CsvDoc.RowCount - 1;
                    CsvDoc.UnloadFile();

                    if (RecordCount < 1)
                    {
                        Directory.CreateDirectory(QuarantinedFolder);
                        Console.WriteLine("Empty data file " + file.Name + ", moving it to quarantine folder.");
                        file.MoveTo(QuarantinedFolder + file.Name);
                        Console.WriteLine("Moved: " + file.Name + " to " + QuarantinedFolder);
                    }
                    else
                    {
                        Console.WriteLine("File: " + file.Name + " is good!");
                    }
                }
            }
        }
    }
}

﻿using LibertyUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinSCP;

namespace FizzBuzz.Scripts.Inlist
{
    class InList : BaseDownloadScript
    {
        string[] roots = {
                @"/Stat Doc/DTE OFR/a/",
                @"/Stat Doc/DTE OFR/b/",
                @"/Stat Doc/CCTV CEO OFR/",
                @"/Stat Doc/BLE OFR/",
                @"/Correspondence/1st Class/",
                @"/Correspondence/2nd Class/"
            };
        string time = DateTime.Now.ToString("H:mm:ss");
        public InList()
        {
            string root = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\";

            DebugLogDir = @"C:\PPProject\c# Projects\Test\ppwatch\Ealing\InList\";
            WorkingDir = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\DataIn\";

            CredentialsPath = HostPath.ppwatch_1 + @"LibertyConfig\ExternalCredentials.xml";
            var ftpCredentials = Credentials.Get("Parking - Ealing");

            //Log.Default.Write("Gathering Local Data File Information...");
            //CSVProcess(root);

            //Log.Default.Write("Gathering Server PDF Information...");
            //PDFProcess(ftpCredentials, roots);

            Log.Default.Write("Creating CSV files for email");
            CSVFOREMAIL();
            Log.Default.Write("Finished Sending Email!");
        }
        string statdocsContents = Environment.NewLine + "Data Files [Downloaded]" + Environment.NewLine + "-----------------------" + Environment.NewLine;
        string corresContents = Environment.NewLine + "Correspondence [Server]" + Environment.NewLine + "-----------------------" + Environment.NewLine;

        private void CSVProcess(string root)
        {
            // Gather all the csv files in the downloaded folder
            string[] fileListcsv = System.IO.Directory.GetFiles(root, "*.csv");

            List<string> DATAFILES = new List<string>();

            // Add the data files to a cumulative list
            foreach (var file in fileListcsv)
                DATAFILES.Add(file);

            foreach (var data in DATAFILES)
            {
                int linecount = (System.IO.File.ReadAllLines(data).Length - 1);
                statdocsContents += "DataFile: " + System.IO.Path.GetFileName(data) + " | Total Lines: " + linecount.ToString() + Environment.NewLine;
            }
        }

        private void PDFProcess(LibertyConfigExternalCredentials.Credential cred, string[] root)
        {
            // get file info from the ftp
            SessionOptions sessionOptions = establishConnection(cred);
            Session session = new Session();
            int count;

            try
            {
                using (session)
                {
                    session.Open(sessionOptions);
                    if (session.Opened)
                    {
                        statdocsContents += Environment.NewLine + "Stat Docs [Server]" + Environment.NewLine + "------------------" + Environment.NewLine;
                        RemoteDirectoryInfo directory;
                        foreach (var dir in root)
                        {
                            directory = session.ListDirectory(dir);
                            count = 0;

                            foreach (RemoteFileInfo info in directory.Files)
                            {
                                if (!info.IsDirectory && (info.Name.Contains("PDF") || info.Name.Contains("pdf"))) { count++; }
                            }

                            bool corres = (dir.IndexOf("Correspondence") != -1) ? true : false;

                            if (corres)
                            {
                                corresContents += "Directory: " + dir + " | Total PDFs : " + count + Environment.NewLine;
                            }
                            else
                            {
                                statdocsContents += "Directory: " + dir + " | Total PDFs : " + count + Environment.NewLine;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed when talking with the server: " + ex);
            }
            finally
            {
                //sendEmail();
            }
        }

        /// <returns>
        /// item1 - Data file name
        /// item2 - Line count
        /// </returns>
        private List<Tuple<string, int>> data_()
        {
            string[] csvfiles = System.IO.Directory.GetFiles(WorkingDir, "*.csv");
            List<Tuple<string, int>> info = new List<Tuple<string, int>>();
            foreach (var csv in csvfiles)
            {
                int linecount = System.IO.File.ReadAllLines(csv).Length - 1;
                info.Add(new Tuple<string, int>(System.IO.Path.GetFileNameWithoutExtension(csv), linecount));
            }

            if (csvfiles.Count() == 0)
            {
                info.Add(new Tuple<string, int>("NO DATA FOUND", 0));
            }
            return info;
        }

        /// <returns>
        /// item1 - PDF directory
        /// item2 - Count of pdfs in that directory
        /// </returns>
        private List<Tuple<string, int>> pdf_()
        {
            List<Tuple<string, int>> info = new List<Tuple<string, int>>();
            var ftpCredentials = Credentials.Get("Parking - Ealing");
            SessionOptions sessionOptions = establishConnection(ftpCredentials);
            Session session = new Session();
            int count;
            using (session)
            {
                session.Open(sessionOptions);
                if (session.Opened)
                {
                    RemoteDirectoryInfo directory;
                    foreach (var dir in roots)
                    {
                        directory = session.ListDirectory(dir);
                        count = 0;
                        foreach (RemoteFileInfo rinfo in directory.Files)
                        {
                            if (!rinfo.IsDirectory && (rinfo.Name.Contains("PDF") || rinfo.Name.Contains("pdf"))) { count++; }
                        }
                        info.Add(new Tuple<string, int>(dir, count));
                    }
                }
            }
            return info;
        }

        private void CSVFOREMAIL()
        {

            string pdfCSV = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\Pdf_" + DateTime.Today.ToString("yyyMMdd") + ".csv";
            Log.Write("Calculating pdf count and adding it to: Pdf_" + DateTime.Today.ToString("yyyMMdd") + ".csv");
            pdfcsv(pdfCSV);
            string dataCSV = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\Data_" + DateTime.Today.ToString("yyyMMdd") + ".csv";
            Log.Write("Calculating line counts in the data files and adding it to: Data_" + DateTime.Today.ToString("yyyMMdd") + ".csv");
            datacsv(dataCSV);
        }

        private void pdfcsv(string file)
        {
            //string file = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\PDF" + DateTime.Today.ToString("yyyMMdd") + ".csv";
            if (!System.IO.File.Exists(file))
            {
                Log.Write(Environment.NewLine + "CSV file not found for email. - PDF");
                Log.Write("Creating csv for emails - PDF");
                string header = "Location" + "," + "Total PDFs" + "\r\n";
                System.IO.File.WriteAllText(file, header);
            }
            string rows = string.Empty;
            rows += time + "\r\n";
            foreach (var item in pdf_())
            {
                rows += item.Item1 + "," + item.Item2.ToString() + "\r\n";
            }
            System.IO.File.AppendAllText(file, rows);
        }

        private void datacsv(string file)
        {
            //string file = @"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\Data" + DateTime.Today.ToString("yyyMMdd") + ".csv";
            if (!System.IO.File.Exists(file))
            {
                Log.Write(Environment.NewLine + "CSV file not found for email. - Data File");
                Log.Write("Creating csv for emails - Data File");
                string header = "Data File" + "," + "Total Lines" + "\r\n";
                System.IO.File.WriteAllText(file, header);
            }
            string rows = string.Empty;
            rows += time + "\r\n";
            foreach (var line in data_())
            {
                rows += line.Item1 + "," + line.Item2 + "\r\n";
            }
            System.IO.File.AppendAllText(file, rows);
        }

        private void sendEmail()
        {
            string emailString = statdocsContents + corresContents;

            // Parse the csv files create for the email process at different times
            string[] filesToCollect = System.IO.Directory.GetFiles(@"C:\PPProject\c# Projects\Test\uploads\ppwatch\Ealing\", "*.csv");

            string emailStringBuilder = String.Empty;
            // read each of the files
            foreach (var file in filesToCollect)
            {
                System.IO.StreamReader reader = new System.IO.StreamReader(System.IO.File.OpenRead(file));


            }

            #region The Actual Email
            EmailUtils.Send(
                to: new string[] { "rachit.giri@libertyservices.co.uk" },
                from: "rachit.giri@libertyservices.co.uk",
                fromName: "Liberty Services",
                subject: "Ealing: Script Report",
                body:
                @"The list of data files that were initally downloaded to be processed and the total number of PDFs that are to be processed are listed below.
                    " + emailString + @"           
Kind regards,

Liberty Services Team
Liberty Services
3 Stafford Cross
Stafford Road
Croydon
CR0 4TU

Tel: +44 0208 681 4110 < Option 2 >
Email: data@libertyservices.co.uk
                    "
            );
            #endregion

        }

        private void addString(string holder, string input)
        {
            holder += input;
        }

        private SessionOptions establishConnection(LibertyConfigExternalCredentials.Credential credentials)
        {
            int port = int.Parse(credentials.Server.Substring(credentials.Server.LastIndexOf(':') + 1));
            string server = credentials.Server;
            int serverIndex = credentials.Server.IndexOf(':');
            if (serverIndex > 0) { server = server.Substring(0, serverIndex); }

            SessionOptions sessionOptions = new SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = server,
                PortNumber = port,
                UserName = credentials.Username,
                Password = credentials.Password,
                GiveUpSecurityAndAcceptAnySshHostKey = true // This needs changing to have it go through a security protocol
            };
            return sessionOptions;
        }
    }
}

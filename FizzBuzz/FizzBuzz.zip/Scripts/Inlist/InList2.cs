﻿using LibertyUtils;
using System;
using System.Collections.Generic;
using System.IO;
using WinSCP;

namespace FizzBuzz.Scripts.Inlist
{
    class InList2 : BaseDownloadScript
    {
        string[] ServerLookupLocations =
        {
            @"/Stat Doc/DTE OFR/a/",
            @"/Stat Doc/DTE OFR/b/",
            @"/Stat Doc/CCTV CEO OFR/",
            @"/Stat Doc/BLE OFR/",
            @"/Correspondence/1st Class/",
            @"/Correspondence/2nd Class/"
        };

        LibertyConfigExternalCredentials.Credential ftpCredentials;
        public InList2()
        {
            CredentialsPath = HostPath.ppwatch_1 + @"LibertyConfig\ExternalCredentials.xml";
            ftpCredentials = Credentials.Get("Parking - Ealing");

            List<Tuple<string, int>> RemoteFileInfo = new List<Tuple<string, int>>();

            // Gather data from the remote server
            SessionOptions sessionOptions = SessionConfig();
            Session session = new Session();
            int count;
            using (session)
            {
                session.Open(sessionOptions);
                if (session.Opened)
                {
                    RemoteDirectoryInfo directory;
                    foreach (var dir in ServerLookupLocations)
                    {
                        directory = session.ListDirectory(dir);
                        count = 0;
                        foreach (RemoteFileInfo rinfo in directory.Files)
                        {
                            if (!rinfo.IsDirectory && (rinfo.Name.Contains("PDF") || rinfo.Name.Contains("pdf"))) { count++; }
                        }
                        RemoteFileInfo.Add(new Tuple<string, int>(dir, count));
                    }
                }
            }

            MakeInlist(RemoteFileInfo, "Brent Download");
        }

        private void MakeInlist(List<Tuple<string, int>> FileInfo, string ProcessType)
        {
            string time = DateTime.Now.ToString("H:mm:ss");
            string InlistFilename = HostPath.ppwatch_2 + @"Data\Ealing\Process\Inlist\" + ProcessType + " Report_" + DateTime.Today.ToString("ddMMyyyy") + ".csv";
            if (!File.Exists(InlistFilename))
            {
                Log.Write("Creating reports file: " + InlistFilename);
                string header = "Location" + "," + "Total PDFs" + "\r\n";
                File.WriteAllText(InlistFilename, header);
            }
            string Rows = string.Empty;
            Rows += ProcessType + " at: " + time + "\r\n";
            foreach (var info in FileInfo)
            {
                Rows += info.Item1 + "," + info.Item2.ToString() + "\r\n";
            }
            File.AppendAllText(path: InlistFilename, contents: Rows);
        }

        private SessionOptions SessionConfig()
        {
            int port = int.Parse(ftpCredentials.Server.Substring(ftpCredentials.Server.LastIndexOf(':') + 1));
            string server = ftpCredentials.Server;
            int serverIndex = ftpCredentials.Server.IndexOf(':');
            if (serverIndex > 0) { server = server.Substring(0, serverIndex); }

            SessionOptions sessionOptions = new SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = server,
                PortNumber = port,
                UserName = ftpCredentials.Username,
                Password = ftpCredentials.Password,
                GiveUpSecurityAndAcceptAnySshHostKey = true // This needs changing to have it go through a security protocol
            };
            return sessionOptions;
        }
    }
}

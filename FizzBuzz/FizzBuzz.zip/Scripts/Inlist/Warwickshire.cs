﻿using System;
using System.Collections.Generic;
using System.Linq;
using LibertyUtils;
using System.IO;

namespace FizzBuzz.Scripts.Inlist
{
    class Warwickshire : BaseDownloadScript
    {
        string AwaitingDownloadsDir;
        public Warwickshire()
        {
            DebugLogDir = @"C:\PPProject\c# Projects\Test\ppwatch\Inlist Tests\Warwickshire\";
            WorkingDir = @"C:\PPProject\c# Projects\Test\ppwatch\Inlist Tests\Warwickshire\WorkingDir\";
            AwaitingDownloadsDir = @"C:\PPProject\c# Projects\Test\ppwatch\Inlist Tests\Warwickshire\AwaitingUpload\";
            string[] patterns = { "*.csv", "*.WRK" };
            foreach(var pattern in patterns)
            {
                List<WorkingFile> workingFiles = GatherLocalData<WorkingFile>(
                    from: AwaitingDownloadsDir,
                    to: WorkingDir,
                    searchPattern: pattern,
                    searchOption: SearchOption.TopDirectoryOnly,
                    clearDestination: true
                );

                if(workingFiles.Count == 0)
                {
                    Log.Write("No Data");
                }
                else
                {
                    Log.Write("Building InList");
                    foreach(WorkingFile wf in workingFiles)
                    {
                        try
                        {
                            BuildInList(wf);
                        }
                        catch (Exception ex)
                        {
                            Log.Write(ex);
                            continue;
                        }
                        Log.Write("Finished Building inlist file for ");                   
                    }
                }
            }
        }

        private void BuildInList(WorkingFile wf)
        {
            int lineCount = File.ReadAllLines(wf.WorkingPath).Count() - 1;
            string InList_Filename = "Warwickshire-" + DateTime.Now.ToString("dd-MM-yyyy") + ".csv";
            string InList_FileLocation = @"C:\PPProject\c# Projects\Test\ppwatch\Inlist Tests\Warwickshire\InList\";
            Console.WriteLine("Inlist Line: " + CSVDocument.QuoteWrapCommaDelimit(new string[] { "Warwickshire", DateTime.Now.ToString("dd-MM-yyyy"), DateTime.Now.ToString("HH:mm:ss"), Path.GetFileName(wf.WorkingPath), lineCount.ToString() }) + Environment.NewLine);
            File.AppendAllText(InList_FileLocation + InList_Filename, CSVDocument.QuoteWrapCommaDelimit(new string[] { "Warwickshire", DateTime.Now.ToString("dd-MM-yyyy"), DateTime.Now.ToString("HH:mm:ss"), Path.GetFileName(wf.WorkingPath), lineCount.ToString() }) + Environment.NewLine);
        }
    }
}


﻿using LibertyUtils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.Scripts.Inlist
{
    class Kingston
    {
        string TempPath;
        string Inlist_Name;
        string Inlist_Path;
        public Kingston()
        {
            TempPath = @"C:\PPProject\c# Projects\Test\ppwatch\Kingston\Test Files\";
            BuildInlist();
        }


        private void BuildInlist()
        {
            List<Tuple<int, string>> F = new List<Tuple<int, string>>();
            
            // Get all the files and check if they have an extension
            foreach(var file in Directory.EnumerateFiles(TempPath, "*", SearchOption.TopDirectoryOnly))
            {
                if(!Path.HasExtension(file))
                {
                    int lineCount = File.ReadAllLines(file).Count() - 1;
                    F.Add(new Tuple<int, string>(lineCount, file));
                }
            }
            Console.WriteLine("Building Inlist");
            Inlist_Path = @"C:\PPProject\c# Projects\Test\ppwatch\Inlist Tests\Kingston\";
            Inlist_Name = "Kingston-" + DateTime.Now.ToString("dd-MM-yyyy") + ".csv";

            foreach (var file in F)
            {
                File.AppendAllText(Inlist_Path + Inlist_Name, CSVDocument.QuoteWrapCommaDelimit(new string[] { "Kingston", DateTime.Now.ToString("dd-MM-yyyy"), DateTime.Now.ToString("HH:mm:ss"), Path.GetFileNameWithoutExtension(file.Item2), file.Item1.ToString()}) + Environment.NewLine);
            }
        }
    }
}
